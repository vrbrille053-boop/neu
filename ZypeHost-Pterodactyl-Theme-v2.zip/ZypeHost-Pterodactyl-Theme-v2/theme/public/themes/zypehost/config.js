window.ZypeHostConfig = {
  brand: 'ZypeHost',
  logo: 'https://raw.githubusercontent.com/vrbrille053-boop/Teama/5988d018d2e8674cac0a84c8c4be3ce6531e6951/0cac12af-dfee-416c-ae51-baf13e899cee.jpeg',
  accent: '#7c3aed',
  accent2: '#2563eb'
};
