(function () {
  'use strict';

  var C = window.ZypeHostConfig || {
    brand: 'ZypeHost',
    logo: 'https://raw.githubusercontent.com/vrbrille053-boop/Teama/5988d018d2e8674cac0a84c8c4be3ce6531e6951/0cac12af-dfee-416c-ae51-baf13e899cee.jpeg'
  };

  var replacements = new Map([
    ['Login to Continue', 'ZypeHost Login'],
    ['Pterodactyl Software', 'ZypeHost'],
    ['Pterodactyl Panel', 'ZypeHost'],
    ['Pterodactyl®', 'ZypeHost'],
    ['Pterodactyl', 'ZypeHost']
  ]);

  var skipTags = {SCRIPT:1, STYLE:1, CODE:1, PRE:1, TEXTAREA:1};
  var scheduled = false;

  function walkText(root) {
    var walker = document.createTreeWalker(root, NodeFilter.SHOW_TEXT);
    var list = [], node;
    while ((node = walker.nextNode())) {
      if (node.parentElement && !skipTags[node.parentElement.tagName]) list.push(node);
    }
    list.forEach(function (text) {
      var value = text.nodeValue || '';
      replacements.forEach(function (to, from) {
        if (value.indexOf(from) !== -1) value = value.split(from).join(to);
      });
      text.nodeValue = value;
    });
  }

  function removePteroFooter() {
    document.querySelectorAll('a[href*="pterodactyl.io"], a[href*="github.com/pterodactyl"]').forEach(function (a) {
      var parent = a.closest('footer, div');
      if (parent && ((parent.textContent || '').toLowerCase().indexOf('pterodactyl') !== -1 || /©/.test(parent.textContent || ''))) {
        parent.style.display = 'none';
      } else {
        a.style.display = 'none';
      }
    });
  }

  function addLogo() {
    var login = location.pathname.indexOf('/auth/login') === 0 || !!document.querySelector('input[type="password"]');
    if (!login) return;
    var form = document.querySelector('form');
    if (!form || document.querySelector('.zh-login-brand')) return;

    var host = form;
    for (var i = 0; i < 4 && host.parentElement; i++) host = host.parentElement;
    host.classList.add('zh-login-card');

    var brand = document.createElement('div');
    brand.className = 'zh-login-brand';
    brand.innerHTML = '<img src="' + C.logo + '" alt="ZypeHost">' +
      '<div><strong>ZypeHost</strong><span>Game Server Hosting</span></div>';
    host.insertBefore(brand, host.firstChild);

    document.body.classList.add('zh-login-page');
  }

  function apply() {
    document.documentElement.style.setProperty('--zh-accent', C.accent || '#7c3aed');
    document.documentElement.style.setProperty('--zh-accent-2', C.accent2 || '#2563eb');
    document.body.classList.add('zypehost');
    document.title = C.brand;
    walkText(document.body);
    removePteroFooter();
    addLogo();
  }

  function schedule() {
    if (scheduled) return;
    scheduled = true;
    requestAnimationFrame(function () {
      scheduled = false;
      apply();
    });
  }

  function boot() {
    apply();
    new MutationObserver(schedule).observe(document.body, {childList:true, subtree:true, characterData:true});
  }

  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', boot, {once:true});
  else boot();
})();
