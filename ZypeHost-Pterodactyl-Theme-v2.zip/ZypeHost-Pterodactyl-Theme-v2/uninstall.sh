#!/usr/bin/env bash
set -Eeuo pipefail
PANEL_DIR="${PTERODACTYL_DIR:-/var/www/pterodactyl}"
ROOT="$PANEL_DIR/storage/zypehost-backups"

latest="$(find "$ROOT" -mindepth 1 -maxdepth 1 -type d -name 'v2-*' -printf '%T@ %p\n' 2>/dev/null | sort -nr | head -1 | cut -d' ' -f2-)"
[[ -n "$latest" && -d "$latest" ]] || { echo "[ZypeHost] Kein v2-Backup gefunden." >&2; exit 1; }

echo "Wiederherstellen: $latest"
read -r -p 'ZypeHost v2 entfernen? [yes/no] ' ans
[[ "$ans" == yes ]] || exit 0

restore() {
  local rel="$1"
  if [[ -e "$latest/$rel" ]]; then
    mkdir -p "$(dirname "$PANEL_DIR/$rel")"
    cp -a "$latest/$rel" "$PANEL_DIR/$rel"
  fi
}

restore resources/views/templates/base/core.blade.php
restore resources/views/layouts/admin.blade.php
restore resources/scripts/index.tsx
restore .env

rm -rf "$PANEL_DIR/public/themes/zypehost"
cd "$PANEL_DIR"
php artisan optimize:clear
php artisan view:clear || true
php artisan up || true

echo "[ZypeHost] v2 entfernt."
