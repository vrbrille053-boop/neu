# ZypeHost Pterodactyl Theme v2

Dieses Paket setzt das sichtbare Pterodactyl-Branding auf **ZypeHost** und bindet dein Logo ein.

Die v2-Variante lädt das Branding **serverseitig über Blade**. Dadurch ist der sichtbare Login- und Footer-Text auch dann betroffen, wenn das React-Frontend noch nicht neu gebaut wurde.

## Enthalten

- ZypeHost Logo auf der Login-Seite
- "Login to Continue" -> "ZypeHost Login"
- sichtbare Pterodactyl-Bezeichnungen -> ZypeHost
- Pterodactyl-Copyright/Footer wird ausgeblendet
- Pterodactyl-Weblinks im sichtbaren Footer werden entfernt
- ZypeHost Dark UI
- Sidebar/Navigation Styling
- Dashboard/Card/Buttons Styling
- Server-/Console Styling
- Mobile Layout
- dezente Animationen
- Backup und Uninstaller

reCAPTCHA wird **nicht deaktiviert**. Es ist eine Sicherheitsfunktion und keine Werbung.

## Installation

```bash
unzip ZypeHost-Pterodactyl-Theme-v2.zip -d /root/zypehost-theme
cd /root/zypehost-theme/ZypeHost-Pterodactyl-Theme-v2
bash install.sh
```

Oder mit anderem Panel-Pfad:

```bash
PTERODACTYL_DIR=/var/www/pterodactyl bash install.sh
```

## Logo

Das Logo wird commit-gepinnt von deinem GitHub-Repostitory geladen:

`https://raw.githubusercontent.com/vrbrille053-boop/Teama/5988d018d2e8674cac0a84c8c4be3ce6531e6951/0cac12af-dfee-416c-ae51-baf13e899cee.jpeg`

Die URL kann später in `theme/public/themes/zypehost/config.js` geändert werden.

## GitHub Ein-Befehl

Nach dem Hochladen in dein Repository:

```bash
bash <(curl -fsSL https://raw.githubusercontent.com/vrbrille053-boop/neu/main/install.sh)
```
