#!/usr/bin/env bash
set -Eeuo pipefail
PANEL_DIR="${PTERODACTYL_DIR:-/var/www/pterodactyl}"
STAMP="$(date +%Y%m%d-%H%M%S)"
DEST="$PANEL_DIR/storage/zypehost-backups/manual-$STAMP"
mkdir -p "$DEST"
for rel in resources/views/templates/base/core.blade.php resources/views/layouts/admin.blade.php resources/scripts/index.tsx .env; do
  if [[ -e "$PANEL_DIR/$rel" ]]; then
    mkdir -p "$(dirname "$DEST/$rel")"
    cp -a "$PANEL_DIR/$rel" "$DEST/$rel"
  fi
done
echo "$DEST"
