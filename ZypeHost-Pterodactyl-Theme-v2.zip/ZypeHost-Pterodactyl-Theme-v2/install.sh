#!/usr/bin/env bash
set -Eeuo pipefail

PANEL_DIR="${PTERODACTYL_DIR:-/var/www/pterodactyl}"
SCRIPT_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
SOURCE_DIR="$SCRIPT_DIR/theme"
STAMP="$(date +%Y%m%d-%H%M%S)"
BACKUP_DIR="$PANEL_DIR/storage/zypehost-backups/v2-$STAMP"

err() { echo "[ZypeHost] ERROR: $*" >&2; exit 1; }

[[ -d "$PANEL_DIR" ]] || err "Panel-Verzeichnis fehlt: $PANEL_DIR"
[[ -f "$PANEL_DIR/artisan" ]] || err "artisan fehlt."
[[ -f "$PANEL_DIR/resources/scripts/index.tsx" ]] || err "index.tsx fehlt."
[[ -f "$PANEL_DIR/resources/views/templates/base/core.blade.php" ]] || err "base/core.blade.php fehlt."
[[ -d "$SOURCE_DIR" ]] || err "Theme-Ordner fehlt."

mkdir -p "$BACKUP_DIR"

backup() {
  local rel="$1"
  if [[ -e "$PANEL_DIR/$rel" ]]; then
    mkdir -p "$(dirname "$BACKUP_DIR/$rel")"
    cp -a "$PANEL_DIR/$rel" "$BACKUP_DIR/$rel"
  fi
}

backup "resources/views/templates/base/core.blade.php"
backup "resources/views/layouts/admin.blade.php"
backup "resources/scripts/index.tsx"
backup ".env"

mkdir -p "$PANEL_DIR/public/themes/zypehost"
cp -a "$SOURCE_DIR/public/themes/zypehost/." "$PANEL_DIR/public/themes/zypehost/"

patch_head() {
  local file="$1"
  local marker="ZYPEHOST_GLOBAL_THEME_V2"
  [[ -f "$file" ]] || return 0
  grep -q "$marker" "$file" && return 0
  python3 - "$file" <<'PY'
from pathlib import Path
import sys
p = Path(sys.argv[1])
s = p.read_text(encoding='utf-8')
needle = '</head>'
block = '''<!-- ZYPEHOST_GLOBAL_THEME_V2 -->
<link rel="icon" type="image/svg+xml" href="/themes/zypehost/zypehost.svg">
<link rel="stylesheet" href="/themes/zypehost/branding.css">
<script defer src="/themes/zypehost/branding.js"></script>
<!-- /ZYPEHOST_GLOBAL_THEME_V2 -->
'''
if needle in s:
    s = s.replace(needle, block + needle, 1)
    p.write_text(s, encoding='utf-8')
else:
    raise SystemExit(f'Kein </head> in {p}')
PY
}

patch_head "$PANEL_DIR/resources/views/templates/base/core.blade.php"
patch_head "$PANEL_DIR/resources/views/layouts/admin.blade.php"

if [[ -f "$PANEL_DIR/.env" ]]; then
  if grep -q '^APP_NAME=' "$PANEL_DIR/.env"; then
    sed -i -E 's/^APP_NAME=.*/APP_NAME=ZypeHost/' "$PANEL_DIR/.env"
  else
    printf '\nAPP_NAME=ZypeHost\n' >> "$PANEL_DIR/.env"
  fi
fi

cd "$PANEL_DIR"
php artisan optimize:clear
php artisan view:clear || true
php artisan up || true

chown -R www-data:www-data "$PANEL_DIR/public/themes/zypehost" 2>/dev/null || true

echo
 echo "=========================================="
echo " ZypeHost v2 installiert"
echo " Backup: $BACKUP_DIR"
echo "=========================================="
echo "Browser danach mit Strg+F5/Hard Reload aktualisieren."
