import './theme.css';
import { ZypeHostTheme } from './config';

const BRAND = ZypeHostTheme.brand;
const SKIP = new Set(['SCRIPT', 'STYLE', 'CODE', 'PRE', 'TEXTAREA']);

function replaceBranding(root: Node): void {
    const walker = document.createTreeWalker(root, NodeFilter.SHOW_TEXT);
    const nodes: Text[] = [];
    let n: Node | null;
    while ((n = walker.nextNode())) {
        const p = n.parentElement;
        if (p && !SKIP.has(p.tagName)) nodes.push(n as Text);
    }
    for (const node of nodes) {
        node.nodeValue = (node.nodeValue || '').replace(/Pterodactyl(?:®)?/g, BRAND);
    }
}

function apply(): void {
    const r = document.documentElement;
    r.style.setProperty('--zh-accent', ZypeHostTheme.accent);
    r.style.setProperty('--zh-accent-2', ZypeHostTheme.accent2);
    r.style.setProperty('--zh-background', ZypeHostTheme.background);
    r.style.setProperty('--zh-panel', ZypeHostTheme.panel);
    r.style.setProperty('--zh-panel-alt', ZypeHostTheme.panelAlt);
    r.style.setProperty('--zh-text', ZypeHostTheme.text);
    r.style.setProperty('--zh-muted', ZypeHostTheme.muted);

    const path = location.pathname;
    document.body.classList.add('zypehost');
    document.body.classList.toggle('zh-auth', path.startsWith('/auth'));
    document.body.classList.toggle('zh-server', path.startsWith('/server/'));
    ensureLoginLogo();
    document.title = BRAND;

    if (!document.querySelector('link[data-zypehost-favicon]')) {
        const link = document.createElement('link');
        link.rel = 'icon';
        link.type = 'image/svg+xml';
        link.href = '/themes/zypehost/zypehost.svg';
        link.dataset.zypehostFavicon = 'true';
        document.head.appendChild(link);
    }
    replaceBranding(document.body);
}

function boot(): void {
    apply();
    let queued = false;
    const observer = new MutationObserver(() => {
        if (queued) return;
        queued = true;
        requestAnimationFrame(() => {
            queued = false;
            apply();
        });
    });
    observer.observe(document.body, { childList: true, subtree: true, characterData: true });
}

if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', boot, { once: true });
} else {
    boot();
}
