export const ZypeHostTheme = {
    brand: 'ZypeHost',
    accent: '#7c3aed',
    accent2: '#2563eb',
    background: '#070b14',
    panel: '#0d1320',
    panelAlt: '#111827',
    text: '#f8fafc',
    muted: '#94a3b8',
};
